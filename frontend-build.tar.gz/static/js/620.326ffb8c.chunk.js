"use strict";(globalThis.webpackChunkfrontend=globalThis.webpackChunkfrontend||[]).push([[620],{7620(n,e,s){s.r(e),s.d(e,{default:()=>t});const t={}}}]);
//# sourceMappingURL=620.326ffb8c.chunk.js.map