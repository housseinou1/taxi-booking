"""Locations migrations."""
